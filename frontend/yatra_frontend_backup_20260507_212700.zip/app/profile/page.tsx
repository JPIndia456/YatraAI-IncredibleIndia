'use client';

import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Camera, Save, User, Mail, Phone, Globe, ArrowLeft, Shield, Activity, Compass, Sparkles } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { useProfile, type Profile } from '@/hooks/useProfile';
import { supabase } from '@/lib/supabase/client';

export default function ProfilePage() {
  const router = useRouter();
  const { user, loading: authLoading, signOut } = useAuth();
  const { getProfile, updateProfile, uploadAvatar, uploading } = useProfile();

  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [tripCount, setTripCount] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Form state
  const [form, setForm] = useState({ 
    full_name: '', 
    email: '',
    phone: '', 
    preferred_language: 'en',
    user_persona: 'Cultural Explorer',
    likes: '',
    dislikes: ''
  });

  useEffect(() => {
    if (!authLoading && !user) router.push('/');
  }, [user, authLoading, router]);

  useEffect(() => {
    async function load() {
      if (!user) return;
      const p = await getProfile();
      if (p) {
        setProfile(p);
        setAvatarUrl(p.avatar_url || null);
        setForm({
          full_name: p.full_name || user?.user_metadata?.full_name || '',
          email: p.email || user?.email || '',
          phone: p.phone || user?.phone || '',
          preferred_language: p.preferred_language || 'en',
          user_persona: p.user_persona || 'Cultural Explorer',
          likes: p.likes?.join(', ') || '',
          dislikes: p.dislikes?.join(', ') || ''
        });
      } else {
        // Use auth user metadata as fallback
        setForm({
          full_name: user?.user_metadata?.full_name || '',
          email: user?.email || '',
          phone: user?.phone || '',
          preferred_language: 'en',
          user_persona: 'Cultural Explorer',
          likes: '',
          dislikes: ''
        });
      }

      // Count bookings via Supabase
      const { count } = await supabase
        .from('yatra_bookings')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id);
      setTripCount(count || 0);
      setLoading(false);
    }
    if (!authLoading) load();
  }, [user, authLoading]);

  const handleSave = async () => {
    setSaving(true);
    const updates = {
      ...form,
      likes: form.likes.split(',').map(s => s.trim()).filter(Boolean),
      dislikes: form.dislikes.split(',').map(s => s.trim()).filter(Boolean)
    };
    const { error } = await updateProfile(updates);
    if (error) toast.error(error);
    setSaving(false);
  };

  const handleAvatarClick = () => fileInputRef.current?.click();

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = await uploadAvatar(file);
    if (url) setAvatarUrl(url);
  };

  const initials = (form.full_name || user?.email || 'U')
    .split(' ')
    .map((w) => w[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();

  if (loading || authLoading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-cyan-500/30 border-t-cyan-500 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="pt-4 pb-12 space-y-8 max-w-4xl mx-auto px-4">
      <motion.button
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        onClick={() => router.push('/planner')}
        className="flex items-center gap-2 text-slate-400 hover:text-saffron text-sm font-black uppercase tracking-widest transition-colors mb-4"
      >
        <ArrowLeft className="w-4 h-4" /> Back to Planner
      </motion.button>

      {/* Amazon-style Header Banner */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm relative overflow-hidden"
      >
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-saffron via-white to-green" />
        
        <div className="flex flex-col md:flex-row items-center gap-8 relative z-10">
          {/* Avatar */}
          <div className="relative">
            <div
              onClick={handleAvatarClick}
              className="w-32 h-32 rounded-full border-4 border-white bg-slate-100 flex items-center justify-center text-4xl font-black text-slate-300 cursor-pointer hover:border-saffron/20 transition-all relative overflow-hidden group shadow-xl"
            >
              {avatarUrl ? (
                <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
              ) : (
                initials
              )}
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <Camera className="w-6 h-6 text-white" />
              </div>
            </div>
            {uploading && (
              <div className="absolute inset-0 rounded-full bg-white/70 flex items-center justify-center">
                <div className="w-6 h-6 border-2 border-saffron/30 border-t-saffron rounded-full animate-spin" />
              </div>
            )}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              className="hidden"
              onChange={handleAvatarChange}
            />
          </div>

          <div className="flex-1 text-center md:text-left space-y-2">
            <h1 className="text-3xl font-black text-slate-900 uppercase tracking-tight italic">
              {form.full_name || 'Your Profile'}
            </h1>
            <div className="flex flex-wrap justify-center md:justify-start gap-4">
              <span className="flex items-center gap-1.5 text-sm text-slate-500 font-bold">
                <Mail className="w-4 h-4 text-saffron" /> {user?.email}
              </span>
              <span className="flex items-center gap-1.5 text-sm text-slate-500 font-bold">
                <Phone className="w-4 h-4 text-saffron" /> +91 {form.phone || 'Not set'}
              </span>
            </div>
            <div className="pt-4 flex flex-wrap justify-center md:justify-start gap-2">
              <span className="px-3 py-1 bg-saffron/10 text-saffron rounded-full text-[10px] font-black uppercase tracking-widest border border-saffron/20">
                {form.user_persona}
              </span>
              <span className="px-3 py-1 bg-green/10 text-green rounded-full text-[10px] font-black uppercase tracking-widest border border-green/20">
                {tripCount} Trips Planned
              </span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Settings Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Personal Details Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm hover:shadow-md transition-shadow"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2.5 bg-saffron/10 rounded-xl">
              <User className="w-5 h-5 text-saffron" />
            </div>
            <h2 className="font-black text-lg text-slate-900 italic uppercase">Your Details</h2>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-[10px] text-slate-400 uppercase font-black tracking-widest ml-1">Display Name</label>
              <input
                type="text"
                value={form.full_name}
                onChange={(e) => setForm({ ...form, full_name: e.target.value })}
                placeholder="Name"
                className="w-full mt-1 bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 text-sm text-slate-900 font-medium focus:border-saffron focus:bg-white focus:outline-none transition-all"
              />
            </div>

            <div>
              <label className="text-[10px] text-slate-400 uppercase font-black tracking-widest ml-1">Email Address</label>
              <input
                type="email"
                value={form.email}
                readOnly
                className="w-full mt-1 bg-slate-100 border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-400 cursor-not-allowed font-medium"
              />
              <p className="text-[8px] text-slate-300 mt-1 italic ml-1">Managed via Supabase Authentication</p>
            </div>

            <div>
              <label className="text-[10px] text-slate-400 uppercase font-black tracking-widest ml-1">Phone Number</label>
              <div className="relative mt-1">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-sm text-slate-400 font-bold border-r border-slate-200 pr-3">+91</span>
                <input
                  type="tel"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value.replace(/\D/g, '').slice(0, 10) })}
                  placeholder="10-digit number"
                  className="w-full bg-slate-50 border border-slate-100 rounded-xl pl-16 pr-4 py-3 text-sm text-slate-900 font-medium focus:border-saffron focus:bg-white focus:outline-none transition-all"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] text-slate-400 uppercase font-black tracking-widest ml-1">Language</label>
              <select
                value={form.preferred_language}
                onChange={(e) => setForm({ ...form, preferred_language: e.target.value })}
                className="w-full mt-1 bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 text-sm text-slate-900 font-black italic uppercase focus:border-saffron focus:bg-white focus:outline-none transition-all appearance-none"
              >
                <option value="en">English (Official)</option>
                <option value="hi">हिंदी (Hindi)</option>
                <option value="mr">मराठी (Marathi)</option>
                <option value="ta">தமிழ் (Tamil)</option>
                <option value="te">తెలుగు (Telugu)</option>
              </select>
            </div>
          </div>
        </motion.div>

        {/* Travel Persona Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm hover:shadow-md transition-shadow"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2.5 bg-saffron/10 rounded-xl">
              <Compass className="w-5 h-5 text-saffron" />
            </div>
            <h2 className="font-black text-lg text-slate-900 italic uppercase">Travel Style</h2>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-[10px] text-slate-400 uppercase font-black tracking-widest ml-1">User Persona</label>
              <select
                value={form.user_persona}
                onChange={(e) => setForm({ ...form, user_persona: e.target.value })}
                className="w-full mt-1 bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 text-sm text-slate-900 font-black italic uppercase focus:border-saffron focus:bg-white focus:outline-none transition-all appearance-none"
              >
                <option value="Cultural Explorer">Cultural Explorer</option>
                <option value="Adventure Seeker">Adventure Seeker</option>
                <option value="Spiritual Pilgrim">Spiritual Pilgrim</option>
                <option value="Foodie Enthusiast">Foodie Enthusiast</option>
                <option value="Luxury Traveler">Luxury Traveler</option>
                <option value="Budget Backpacker">Budget Backpacker</option>
              </select>
            </div>
            
            <div className="p-4 bg-orange-50 rounded-2xl border border-orange-100">
              <p className="text-[11px] text-saffron font-bold leading-relaxed">
                Your AI Brain uses this persona to filter millions of possibilities into the perfect itinerary. Current persona: <strong className="uppercase">{form.user_persona}</strong>
              </p>
            </div>

            <div className="flex items-center justify-between p-3 border border-slate-100 rounded-2xl">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-green" />
                <span className="text-xs font-black uppercase tracking-widest text-slate-900">Account ID</span>
              </div>
              <span className="text-[10px] font-mono text-slate-300">{user?.id?.slice(0, 12)}...</span>
            </div>
          </div>
        </motion.div>

        {/* Interests Section - Full Width */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="md:col-span-2 bg-white border border-slate-200 rounded-3xl p-6 shadow-sm"
        >
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-saffron/10 rounded-xl">
                <Sparkles className="w-5 h-5 text-saffron" />
              </div>
              <h2 className="font-black text-xl text-slate-900 italic uppercase tracking-tight">Your Interests & Preferences</h2>
            </div>
            <div className="hidden sm:block px-4 py-1 bg-slate-50 border border-slate-100 rounded-full">
              <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.2em]">Amazon-Style Customization</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-3">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-lg">🧡</span>
                <label className="text-[10px] text-slate-900 uppercase font-black tracking-widest">Things You Love</label>
              </div>
              <textarea
                value={form.likes}
                onChange={(e) => setForm({ ...form, likes: e.target.value })}
                placeholder="e.g. Ancient Temples, Street Food, Night Trains, Quiet Mornings"
                className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-5 py-4 text-sm text-slate-900 font-medium focus:border-saffron focus:bg-white focus:outline-none transition-all min-h-[120px] resize-none"
              />
              <p className="text-[10px] text-slate-400 italic">Separate interests with commas to help the AI categorize them.</p>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-lg">🚫</span>
                <label className="text-[10px] text-slate-900 uppercase font-black tracking-widest">Things You Avoid</label>
              </div>
              <textarea
                value={form.dislikes}
                onChange={(e) => setForm({ ...form, dislikes: e.target.value })}
                placeholder="e.g. Crowded Buses, Spicy Food, Early Mornings, Commercial Malls"
                className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-5 py-4 text-sm text-slate-900 font-medium focus:border-orange-500 focus:bg-white focus:outline-none transition-all min-h-[120px] resize-none"
              />
              <p className="text-[10px] text-slate-400 italic">Tell us what ruins a trip so we can skip it entirely.</p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row gap-4 pt-4">
        <button
          onClick={handleSave}
          disabled={saving}
          className="flex-1 py-5 bg-gradient-to-r from-saffron to-orange-600 text-white rounded-2xl font-black text-sm hover:scale-[1.02] active:scale-95 transition-all shadow-xl shadow-saffron/20 disabled:opacity-60 flex items-center justify-center gap-2 uppercase tracking-[0.2em]"
        >
          {saving ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : (
            <><Save className="w-5 h-5" /> Update My Odyssey Profile</>
          )}
        </button>

        <button
          onClick={async () => {
            await signOut();
            router.push('/');
          }}
          className="px-8 py-5 bg-white text-red-500 border border-red-100 rounded-2xl font-black text-sm hover:bg-red-50 transition-all uppercase tracking-widest"
        >
          Sign Out
        </button>
      </div>

      <div className="text-center pt-8">
        <p className="text-[10px] text-slate-300 font-black uppercase tracking-[0.3em]">
          Secured by Supabase & Powered by Gemini AI
        </p>
      </div>
    </div>
  );
}
