import { WizardField } from './store';
import { 
  parseBudget, parseDate, parseAdults, parseTripType, parseLanguage,
  getStartDateChips, getEndDateChips 
} from './wizardParsers';

export const getPlannerWizardSchema = (t: (key: string, def?: string) => string): WizardField[] => [
  {
    id: 'language', label: t('wizard.language.label', 'Support Language'), emoji: '🗣️',
    question: t('wizard.language.question', 'Namaste! I am your AI travel architect. 🇮🇳\n\nTo begin, would you like me to provide travel support in a specific language?'),
    chips: [
      { label: t('language.en', 'English'), value: 'en' },
      { label: t('language.hi', 'Hindi'), value: 'hi' },
      { label: t('language.ta', 'Tamil'), value: 'ta' },
      { label: t('language.mr', 'Marathi'), value: 'mr' },
    ],
    parse: (text) => parseLanguage(text),
    confirm: (v) => {
      const langMap: Record<string, string> = { hi: t('language.hi', 'Hindi'), ta: t('language.ta', 'Tamil'), mr: t('language.mr', 'Marathi'), en: t('language.en', 'English') };
      return t('wizard.language.confirm', `✅ I'll support you in **${langMap[v] || 'English'}**.`).replace('{{value}}', langMap[v] || 'English');
    },
  },
  {
    id: 'tripType', label: t('wizard.tripType.label', 'Trip Type'), emoji: '✈️',
    question: t('wizard.tripType.question', 'Excellent! Are we planning a **Round Trip** or a **Single Trip** (One-way)?'),
    chips: [
      { label: t('wizard.tripType.round', '🔄 Round Trip'), value: 'round' },
      { label: t('wizard.tripType.single', '➡️ One Way'), value: 'single' },
    ],
    parse: (text) => parseTripType(text),
    confirm: (v) => {
      const val = v === 'round' ? t('wizard.tripType.round', 'Round Trip') : t('wizard.tripType.single', 'Single Trip');
      return t('wizard.tripType.confirm', `✅ **${val}** selected.`).replace('{{value}}', val);
    },
  },
  {
    id: 'startDate', label: t('wizard.startDate.label', 'Departure Date'), emoji: '📅',
    question: t('wizard.startDate.question', 'When do you plan to leave?\n\nSay "next weekend", "May 15", or pick below:'),
    chips: getStartDateChips(),
    parse: (text) => parseDate(text),
    confirm: (v) => { 
      try { 
        const dateStr = new Date(String(v)).toLocaleDateString(t('locale', 'en-IN'), { weekday: 'short', day: 'numeric', month: 'long' });
        return t('wizard.startDate.confirm', `✅ Departure set to **${dateStr}**.`).replace('{{value}}', dateStr);
      } catch { 
        return t('wizard.startDate.confirm_fallback', `✅ Departure date saved.`); 
      } 
    },
  },
  {
    id: 'endDate', label: t('wizard.endDate.label', 'Return Date'), emoji: '🔙',
    question: t('wizard.endDate.question', 'When will you return?\n\nSay how many nights (e.g. "5 nights") or pick below:'),
    chips: (collected: Record<string, any>) => getEndDateChips(collected.startDate),
    parse: (text, collected) => {
      const m = text.match(/^(\d+)\s*(?:night|nights|n|days?)?$/i);
      if (m) { const base = collected.startDate ? new Date(String(collected.startDate)) : new Date(); base.setDate(base.getDate() + parseInt(m[1])); return base.toISOString().split('T')[0]; }
      return parseDate(text);
    },
    confirm: (v) => { 
      try { 
        const dateStr = new Date(String(v)).toLocaleDateString(t('locale', 'en-IN'), { weekday: 'short', day: 'numeric', month: 'long' });
        return t('wizard.endDate.confirm', `✅ Return date: **${dateStr}**.`).replace('{{value}}', dateStr);
      } catch { 
        return t('wizard.endDate.confirm_fallback', `✅ Return date saved.`); 
      } 
    },
  },
  {
    id: 'origin', label: t('wizard.origin.label', 'Departure City'), emoji: '🏙️',
    question: t('wizard.origin.question', 'Which city are you departing from?\n\nYour nearest major station or airport:'),
    chips: [
      { label: t('city.delhi', '🏛️ Delhi'), value: 'New Delhi' },
      { label: t('city.mumbai', '🌆 Mumbai'), value: 'Mumbai' },
      { label: t('city.bangalore', '💻 Bangalore'), value: 'Bangalore' },
      { label: t('city.chennai', '🎭 Chennai'), value: 'Chennai' },
      { label: t('city.hyderabad', '🌸 Hyderabad'), value: 'Hyderabad' },
      { label: t('city.kolkata', '📚 Kolkata'), value: 'Kolkata' },
    ],
    parse: (text) => text.trim(),
    confirm: (v) => t('wizard.origin.confirm', `✅ Departing from **${v}**. Got it!`).replace('{{value}}', v),
  },
  {
    id: 'specificDest', label: t('wizard.specificDest.label', 'Destination'), emoji: '🗺️',
    question: t('wizard.specificDest.question', 'Where would you like to travel in India?\n\nType a city name, or tap a popular pick below:'),
    chips: [
      { label: t('dest.manali', '🏔️ Manali'), value: 'Manali, Himachal Pradesh' },
      { label: t('dest.goa', '🏖️ Goa'), value: 'Goa' },
      { label: t('dest.jaipur', '🕌 Jaipur'), value: 'Jaipur, Rajasthan' },
      { label: t('dest.munnar', '🌿 Munnar'), value: 'Munnar, Kerala' },
      { label: t('dest.agra', '🏛️ Agra'), value: 'Agra, Uttar Pradesh' },
      { label: t('dest.varanasi', '🙏 Varanasi'), value: 'Varanasi, UP' },
      { label: t('dest.ladakh', '⛰️ Ladakh'), value: 'Leh, Ladakh' },
      { label: t('dest.andaman', '🌊 Andaman'), value: 'Port Blair, Andaman' },
    ],
    parse: (text) => text.trim(),
    confirm: (v) => t('wizard.specificDest.confirm', `✅ **${v}** — excellent pick!`).replace('{{value}}', v),
  },
  {
    id: 'targetBudget', label: t('wizard.targetBudget.label', 'Total Budget'), emoji: '💰',
    question: t('wizard.targetBudget.question', 'What is your total trip budget for ALL travelers?\n\nSay "30k", "1 lakh", or pick:'),
    chips: [
      { label: '₹15,000', value: '15000' }, { label: '₹30,000', value: '30000' },
      { label: '₹50,000', value: '50000' }, { label: '₹1,00,000', value: '100000' },
      { label: '₹2,00,000', value: '200000' }, { label: '₹5,00,000', value: '500000' },
    ],
    parse: (text) => parseBudget(text),
    confirm: (v) => {
      const val = Number(v).toLocaleString(t('locale', 'en-IN'));
      return t('wizard.targetBudget.confirm', `✅ Budget set to **₹${val}**.`).replace('{{value}}', val);
    },
  },
  {
    id: 'adults', label: t('wizard.adults.label', 'Adults'), emoji: '👥',
    question: t('wizard.adults.question', 'How many adults are travelling?\n\n(Children under 12 can be added on the form afterward)'),
    chips: [
      { label: t('wizard.adults.one', '1 — Just me'), value: '1' }, { label: t('wizard.adults.two', '2 — Couple'), value: '2' },
      { label: t('wizard.adults.three', '3 people'), value: '3' },     { label: t('wizard.adults.four', '4 — Family'), value: '4' },
      { label: t('wizard.adults.five', '5 people'), value: '5' },     { label: t('wizard.adults.six_plus', '6+'), value: '6' },
    ],
    parse: (text) => parseAdults(text),
    confirm: (v) => {
      const label = Number(v) > 1 ? t('wizard.adults.label_plural', 'adults') : t('wizard.adults.label_singular', 'adult');
      return t('wizard.adults.confirm', `✅ Party size: **${v} ${label}**. Perfect!`).replace('{{count}}', String(v)).replace('{{label}}', label);
    },
  },
  {
    id: 'kids', label: t('wizard.kids.label', 'Children'), emoji: '👶',
    question: t('wizard.kids.question', 'Any children under 12 travelling with you?'),
    chips: [
      { label: t('wizard.kids.zero', 'No children'), value: '0' }, { label: t('wizard.kids.one', '1 child'), value: '1' },
      { label: t('wizard.kids.two', '2 children'), value: '2' }, { label: t('wizard.kids.three_plus', '3+ children'), value: '3' },
    ],
    parse: (text) => {
       const n = parseInt(text.replace(/\D/g, ''));
       return isNaN(n) ? 0 : n;
    },
    confirm: (v) => t('wizard.kids.confirm', `✅ **${v}** children. Noted!`).replace('{{value}}', String(v)),
  },
  {
    id: 'dietary', label: t('wizard.dietary.label', 'Dietary'), emoji: '🍱',
    question: t('wizard.dietary.question', 'Any dietary preferences for the group?'),
    chips: [
      { label: t('wizard.dietary.veg', '🥦 Vegetarian'), value: 'veg' },
      { label: t('wizard.dietary.jain', '🥣 Jain'), value: 'jain' },
      { label: t('wizard.dietary.nonveg', '🍗 Non-Veg'), value: 'non-veg' },
      { label: t('wizard.dietary.vegan', '🥗 Vegan'), value: 'vegan' },
    ],
    parse: (text) => {
      const t = text.toLowerCase();
      if (t.includes('jain')) return 'jain';
      if (t.includes('non')) return 'non-veg';
      if (t.includes('vegan')) return 'vegan';
      return 'veg';
    },
    confirm: (v) => {
      const val = t(`wizard.dietary.${v}`, v);
      return t('wizard.dietary.confirm', `✅ Preference set to **${val}**.`).replace('{{value}}', val);
    },
  },
];
